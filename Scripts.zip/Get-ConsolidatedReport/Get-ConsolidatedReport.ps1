﻿[cmdletbinding()]
param (
[Parameter(Mandatory = $true)][string]$Path
)

$Accessible = @()
$NotAccessible = @()

$output = get-location

$Accessible += Get-ChildItem -Path $Path -Filter "*_Accessible.csv" | foreach-object {Import-Csv $_.FullName}
$NotAccessible += Get-ChildItem -Path $Path -Filter "*_NonAccessible.CSV"| foreach-object {Import-Csv $_.FullName}


$Accessible | Export-Csv "$output\Accessible.csv" -NoTypeInformation
$NotAccessible | Export-Csv "$output\NotAccessible.csv" -NoTypeInformation


Write-Host "The output files are saved in $output as Accessible.csv and NotAccessible.csv"