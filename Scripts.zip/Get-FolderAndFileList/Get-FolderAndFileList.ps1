[cmdletbinding()]
param (
[Parameter(Mandatory = $true)][string]$VolumeName
)
$VolumeName
"START"
"---------------------"
"Drive : $($VolumeName)"
$drive = $VolumeName.trim(":\\")
Get-Date > "$($drive)_Start.log"



$MaxParallel = (Get-CimInstance -ClassName Win32_Processor).NumberOfEnabledCore
$output = "$($drive)_Dump"



if (-not (Test-Path $output))
{
mkdir $output
}

$FistLevelFolders = Get-ChildItem -Force -Path $VolumeName -ErrorVariable failedPaths -ErrorAction SilentlyContinue -Directory
$FistLevelFolders | ForEach-Object -Parallel {
$_.FullName
$fileList = Get-ChildItem -Recurse -Force -Path $_.FullName -ErrorVariable failedPaths -ErrorAction SilentlyContinue
$fileList | Select-Object -ExpandProperty FullName
$fileList | ConvertTo-Csv -NoTypeInformation | Out-File ($Using:output + "\\" + $using:drive + "_" + $_.Name + "_Accessible.CSV") -Append
$failedPaths | ConvertTo-Csv -NoTypeInformation | Out-File ($Using:output + "\\" + $using:drive + "_" + $_.Name + "_" + "_NonAccessible.CSV") -Append
} -ThrottleLimit $MaxParallel



Get-Date > "$($VolumeName.trim(":\"))_ENd.log"
"---------------------"
"END"