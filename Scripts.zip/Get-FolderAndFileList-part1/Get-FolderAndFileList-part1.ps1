"START" 
"---------------------"
Get-Date  > "Start.log"
$volumeList = (Get-PSDrive -PSProvider FileSystem).Root
$volumeList
"---------------------"
$MaxParallel = (Get-CimInstance  -ClassName Win32_Processor).NumberOfEnabledCore
$output = "Dump"


$volumeList | ForEach-Object {
  $VolumeName = $_
  $VolumeName
  $FistLevelFolders = Get-ChildItem -Force -Path $_ -ErrorVariable failedPaths -ErrorAction SilentlyContinue -Directory
  $FistLevelFolders | ForEach-Object -Parallel  { 
    $_.FullName
    $fileList = Get-ChildItem -Recurse -Force -Path $_.FullName -ErrorVariable failedPaths -ErrorAction SilentlyContinue 
    $fileList | Select-Object -ExpandProperty  FullName
    $fileList | ConvertTo-Csv -NoTypeInformation | Out-File  ($Using:output + "\\" + $VolumeName + "_" + $_.Name + "_Accessible.CSV") -Append
    $failedPaths | ConvertTo-Csv -NoTypeInformation | Out-File  ($Using:output + "\\" + $VolumeName + "_" + $_.Name + "_" + "_NonAccessible.CSV") -Append
  } -ThrottleLimit $MaxParallel

}
Get-Date > "ENd.log"
"---------------------"
"END" 

